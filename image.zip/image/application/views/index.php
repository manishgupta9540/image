<!DOCTYPE html>
<html>
   <head>
      <title></title>
      <link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/css/bootstrap.min.css';?>">
      <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css">
      <link href="https://cdn.datatables.net/1.10.25/css/dataTables.bootstrap4.min.css">
   </head>
   <body>
      <br><br>
      <div class="container">
         <div class="col-md-2" style="text-align: right;">
            <a href="<?php echo base_url('UserController/create');?>" class="btn btn-info">Add User</a>
         </div>
         <div class="col-md-10">
            <table id="example" class="table bordered table-responsive">
               <thead>
                  <tr>
                     <th>ID</th>
                     <th>Image</th>
                  </tr>
               </thead>
               <tbody>
                  <?php $i=1; foreach($result as $row){ ?>
                  <tr>
                     <td><?php echo $i++ ?></td>
                     <td><img src="<?php echo base_url('images/upload/'.$row->image); ?>" height="60px" width="60px"></td>
                  </tr>
                  <?php } ?>
               </tbody>
            </table>
         </div>
      </div>
      <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
      <script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
      <script src="https://cdn.datatables.net/1.10.25/js/dataTables.bootstrap4.min.js"></script>
      <script>
         $(document).ready(function() {
         	$('#example').DataTable();
         });
      </script>	
   </body>
</html>