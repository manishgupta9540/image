<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class UserController extends CI_Controller {

	public function index()
	{
		$data['result'] = $this->db->get('testimage')->result();
		$this->load->view('index',$data);
	}
	public function create()
	{
		$this->load->view('create');
	}

	public function save()
	{
		$image = $this->input->post('image');


		if (!empty($_FILES['file']['name'])) {
			$_FILES['file']['name']       = $_FILES['file']['name'];
			$_FILES['file']['type']       = $_FILES['file']['type'];
			$_FILES['file']['tmp_name']   = $_FILES['file']['tmp_name'];
			$_FILES['file']['error']      = $_FILES['file']['error'];
			$_FILES['file']['size']       = $_FILES['file']['size'];

			$config['upload_path']   = 'images/upload';
			$config['allowed_types'] = 'gif|jpg|png|jpeg';

			if (!is_dir('images/upload')) {
				mkdir('images/upload', 0777, TRUE);
			}
			$image = '';
			$this->load->library('upload', $config);
			$this->upload->initialize($config);
			if (!$this->upload->do_upload('file')) {
				$image  = '';
			} else {
				$data = $this->upload->data();
				$image =  $data['file_name'];
			}
			//$update_data['image'][] = $thumbnail;
			$image = $image;
		} else {
			$image = '';
		}


		$data = [
			'image' => 	$image
		];

		 $this->db->insert('testimage', $data);
		 redirect('UserController');
	}


}
